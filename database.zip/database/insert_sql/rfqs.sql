INSERT INTO `rfqs` (`id`, `uuid`,  `unique_id`, `issued_by`, `client_id`, `service_request_id`, `status`, `accepted`, `total_amount`, `created_at`, `updated_at`) VALUES
(1, '1045f599-769a-41d0-93bb-06f88ee7357f', 'RFQ-C85BEA04', 2, 5, 1, '1', 'Yes', 5800, '2020-12-28 15:58:54', '2021-01-02 14:38:30');

