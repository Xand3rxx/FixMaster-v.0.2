INSERT INTO `tool_requests` (`id`, `uuid`, `unique_id`, `requested_by`, `approved_by`, `service_request_id`, `status`, `is_returned`, `created_at`, `updated_at`) VALUES
(1, 'ddd659ba-28f7-4002-94f2-467f51e51242', 'TRF-C85BEA04', 2, 22, 1, 'Approved', '1', '2020-12-28 15:58:54', '2020-12-29 14:21:47');
