INSERT INTO `rfq_batches` (`id`, `rfq_id`, `component_name`, `model_number`, `quantity`, `amount`) VALUES
(1, 1, 'Power cable', 'PC-234234', 1, 2500),
(2, 1, '8GB RAM', 'RM-3242', 2, 2500);