INSERT INTO `tool_request_batches` (`id`, `tool_request_id`, `tool_id`, `quantity`) VALUES
(1, 1, 2, 2),
(2, 1, 1, 1);
