INSERT INTO `rfq_suppliers` (`id`, `rfq_id`, `supplier_id`, `devlivery_fee`, `delivery_time`) VALUES
(1, 1, 19, 1450, 'January 2nd 2021, 7:00:00pm'); 
